This case study is based on Lehmann and Rabin's solution to the well known dining philosophers problem [LR81].

For more information, see: http://www.prismmodelchecker.org/casestudies/phil.php

=====================================================================================

[LR81]
D. Lehmann and M. Rabin
On the Advantages of Free Choice: A Symmetric Fully Distributed Solution to the Dining Philosophers Problem (Extended Abstract)
In Proc. 8th Symposium on Principles of Programming Languages, pp. 133-138, 1981
